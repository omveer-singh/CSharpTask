﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_sharp_task
{
    internal class Task
    {
         static void Main(string[] args)
        {
               Average();
                     
               Absolute();
                       
               Compound_Interest();
                        
               Cube();
                     
               Leap_Year();
                     
               Even_Odd();
                        
               Even_Number();
                                         
               Largest_Of_Two_Numbers();
                        
               Largest_Of_Three_Numbers();
                       
               Multipilaction_Table();
                       
               NumDivOnly_5_And_11();
                        
               Interest();
                        
               Armgstrong_Num();
                       
               Prime_Num();
                        
               NumFrom_1_to_11();
                       
               Parallelogram();
                        
               TrapeZoid();
                       
               AreaOf_RightAngledTriangle();
                       
               AreaOf_EquilateralTriangle();
                      
               AreaOf_Rhombas();
                    
               PerimeterOf_Rhombus();
              
               Console.ReadLine();


        }      
        
        private static void Average()
        {
            Console.WriteLine();
            Console.WriteLine("How Many Values You have To Find The Average??");
            Console.WriteLine("Enters a Number : ");
            dynamic num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            double sum = 0;
            dynamic count = 0;
            while(num != 0)
            {
                Console.WriteLine($"EnterVALUE {count + 1} : ");
                dynamic value = Convert.ToInt32(Console.ReadLine());
                sum = sum + value;
                count++;
                num = num - 1;
            }
            double Avg = sum / count;
            Console.WriteLine($"Average : {Avg}");
        }

        private static void Absolute()
        {
            Console.WriteLine("Enters a Number : ");
            dynamic Abs = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (Abs < 0)
                Console.WriteLine($"Absolute Value : {-Abs}");
            else
                Console.WriteLine($"Absolute Value : {Abs}");
                   
        }

        private static void Compound_Interest()
        {
            Console.WriteLine("Enter.. Initial Principal Balance : ");
            double p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter..Interest Rate : ");
            double r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter..Number Of Times Interest Applied Per Time Period : ");
            dynamic n = Convert.ToInt32(Console.ReadLine());
            dynamic CI = p*(Math.Pow(1 + (r / 100),n)) - p;
            Console.WriteLine($"COMPOUND INTEREST : {CI}");
        }

        private static void Cube()
        {
            Console.WriteLine("Enter the Value : ");
            dynamic cube = Convert.ToInt32(Console.ReadLine());
            cube = cube * cube * cube;
            Console.WriteLine();
            Console.WriteLine($"CUBE : {cube}");
        }

        private static void Leap_Year()
        {
            Console.WriteLine("Enter Year: ");
            dynamic Leap_year = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (Leap_year % 4 == 0)
                Console.WriteLine("Leap Year");
            else
                Console.WriteLine("NOT Leap Year");
        }

        private static void Even_Odd()
        {
            Console.WriteLine("Enter The Value");
            dynamic num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num % 2 == 0)
                Console.WriteLine("EVEN NUMBER");
            else
                Console.WriteLine("ODD NUMBER");
        }

        private static void Even_Number()
        {
            Console.WriteLine("Enter Value1");
            dynamic num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Value2");
            dynamic num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            while (num1 != num2 + 1)
            {
                if (num1 % 2 == 0)
                    Console.WriteLine($"EVEN NUMBER{num1}");
                num1++;
            }

        }

        private static void Largest_Of_Two_Numbers()
        {
            Console.WriteLine("Enter Value1");
            dynamic num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Value2");
            dynamic num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num1 > num2)
                Console.WriteLine($"Greater Number{num1}");
            else if (num1 < num2)
                Console.WriteLine($"Greater Number {num2}");
            else
                Console.WriteLine("BOTH NUMBER ARE EQUAL");
        }

        private static void Largest_Of_Three_Numbers()
        {
            Console.WriteLine("Enter Value1");
            dynamic num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Value2");
            dynamic num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Value3");
            dynamic num3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num1 > num2  && num1 > num3)
                Console.WriteLine($"Greater Number {num1}");
            else if (num1 < num2 && num3 < num2)
                Console.WriteLine($"Greater Number {num2}");
            else if (num1 < num3 && num2 < num3)
                Console.WriteLine($"Greater Number{num3}");
            else if(num1 == num2 && num1 < num3)
                Console.WriteLine($"Greater Number{num3}");
            else if(num1 == num2 && num2 > num3)
                Console.WriteLine($"Greater Number{num2}");
            else if(num1 == num3 && num3 < num2)
                Console.WriteLine($"Greater Number{num2}");
            else if(num1 == num3 && num3 > num2)
                Console.WriteLine($"Greater Number{num3}");
            else if(num2 == num3 && num3 < num1)
                Console.WriteLine($"Greater Number{num1}");
            else if(num2 == num3 && num2 > num1)
                Console.WriteLine($"Greater Number{num2}");
            else
                Console.WriteLine($"All Number Are Equal");
        }

        private static void Multipilaction_Table()
        {
            Console.WriteLine("Enter Number");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            int count = 1;
            while (count <= 10)
            {
                Console.WriteLine($"{num} *  {count} :  {num*count}");
                count++;
            }
        }

        private static void NumDivOnly_5_And_11()
        {
            Console.WriteLine("Enter Number");
            dynamic num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num % 5 == 0 && num % 11 == 0)
                Console.WriteLine(" CORRECT NUMBER.");
            else
                Console.WriteLine("NOT CORRECT NUMBER.");
        }

        private static void Interest()
        {
            Console.WriteLine("Enter.. Principal Value : ");
            double p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rate : ");
            double r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Time: ");
            dynamic t = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            dynamic Interest = (p * r * t)/100;
            Console.WriteLine($"Interest is : {Interest}");
        }

        private static void Armgstrong_Num()
        {
            Console.WriteLine("Enter Number--  ");
            string number = Console.ReadLine();
            int length = number.Length;
            int num = Convert.ToInt32(number);
            Console.WriteLine();
            double Armst = 0;
            double Value = num*1;
            while(num != 0)
            {
                double rem = num % 10;
                Armst = Armst + Math.Pow(rem, length);
                num = num / 10;
            }
            if (Value == Armst)
                Console.WriteLine("ARMSTRONG NUMBER");
            else
                Console.WriteLine("NOT ARMSTRONG NUMBER");
        }

        private static void Prime_Num()
        {
            Console.WriteLine("Enter Value");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            int PrimeNumber = num*1;
            num = (num - 1)/2;
            Boolean temp = false;
            while(num > 1)
            {
                if ((PrimeNumber % num) == 0)
                    temp = true;
                num = num - 1;
            }
            
            if(temp == true)
                Console.WriteLine("NOT PRIME NUMBER");
            else
                Console.WriteLine("PRIME NUMBER");

        }

        private static void NumFrom_1_to_11()
        {
            int num = 1;
            Console.WriteLine();
            while (num <= 11)
            {
                Console.WriteLine($"NUMBER{num}");
                num = num + 1;  
            }
        }

        private static void Parallelogram()
        {
            Console.WriteLine("Enter Base--");
            int Base = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Height--");
            int Height = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Area Of Parallelogram{Base * Height}");
        }

        private static void TrapeZoid()
        {
            Console.WriteLine("Enter Base1--");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Base2--");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Height--");
            int h = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Area of TrapeZoid--{((a+b)*h)/2}");
        }

        private static void AreaOf_RightAngledTriangle()
        {
            Console.WriteLine("Enter Base--");
            int Base = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Height--");
            int height = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Area of Right Angled Triangle-- {(Base * height) / 2}");
        }

        private static void AreaOf_EquilateralTriangle()
        {
            Console.WriteLine("Enter Side--");
            int side = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Area Of Equilateral Triangle-- {(1.732*side*side)/4}");
        }

        private static void AreaOf_Rhombas()
        {
            Console.WriteLine("Enter Diagonal_1--");
            int diagonal1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Diagonal_2--");
            int diagonal2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Area of Rhombus-- {(diagonal1 * diagonal2) / 2}");
        }
        private static void PerimeterOf_Rhombus()
        {
            Console.WriteLine("Enter .Side-- ");
            int side = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine($"Perimeter Of Rhombus-- {4 * side}");
        }
    }
}
